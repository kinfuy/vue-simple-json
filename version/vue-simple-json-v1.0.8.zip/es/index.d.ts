import SimpleJson from './simpleJson';
import { deepAnalysisJson, deepReductionJson } from './simpleJson/utils';
export * from './simpleJson/type/simple-json';
export { deepAnalysisJson, deepReductionJson };
export default SimpleJson;
