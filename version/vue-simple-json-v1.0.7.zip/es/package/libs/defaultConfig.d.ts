import { JsonEditorConfig } from './../type/simple-json';
export declare const defaultConfig: JsonEditorConfig;
