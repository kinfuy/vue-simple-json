import { App } from 'vue';
declare const install: (app: App) => void;
export default install;
