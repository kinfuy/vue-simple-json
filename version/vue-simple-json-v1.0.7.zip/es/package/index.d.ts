import { App } from 'vue';
import './components/Icon/iconfont.js';
declare const _default: {
    install: (app: App<any>) => App<any>;
};
export default _default;
