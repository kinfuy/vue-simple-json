export declare const commonDataType: string[];
